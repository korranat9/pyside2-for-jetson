shiboken_library_soversion = str(5.15)

version = "5.15.2.1"
version_info = (5, 15, 2.1, "", "")

__build_date__ = '2022-07-05T10:41:49+00:00'
__build_commit_date__ = '2022-01-07T13:07:42+00:00'
__build_commit_hash__ = '9282e03de471bb3772c8d3997159e49c113d7678'
__build_commit_hash_described__ = 'v5.15.2.1'

__setup_py_package_version__ = '5.15.2.1'
